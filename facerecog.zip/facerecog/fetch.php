<?php
header('Access-Control-Allow-Origin: *');
include 'db.php';
$email = $_POST['email'];

$a=mysqli_query($con,"SELECT * FROM `pegawai` WHERE `email`='$email'");	

while($rs = mysqli_fetch_array($a,MYSQLI_ASSOC)) {
	$rollno = $rs["rollno"];
	$mail = $rs["email"];
	$nama = $rs["nama"];
	$jabatan = $rs["jabatan"];
	$unit = $rs["unit"];
	$idunit = $rs["idunit"];
	}
$inp = file_get_contents('data/'.$rollno.'_neural.json');
$tempArray = json_decode($inp);
$jsonData = json_encode($tempArray);
echo $jsonData;
?>
