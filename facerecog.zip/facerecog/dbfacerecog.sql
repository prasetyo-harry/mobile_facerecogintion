-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 03, 2021 at 12:15 AM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 7.4.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbfacerecog`
--

-- --------------------------------------------------------

--
-- Table structure for table `absensi`
--

CREATE TABLE `absensi` (
  `id` int(11) NOT NULL,
  `rollno` varchar(100) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `nama` varchar(255) DEFAULT NULL,
  `jabatan` varchar(255) DEFAULT NULL,
  `unit` varchar(255) DEFAULT NULL,
  `idunit` varchar(50) DEFAULT NULL,
  `tanggal` varchar(50) DEFAULT NULL,
  `jam` varchar(50) DEFAULT NULL,
  `keterangan` varchar(200) DEFAULT NULL,
  `action` varchar(100) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `absensi`
--

INSERT INTO `absensi` (`id`, `rollno`, `email`, `nama`, `jabatan`, `unit`, `idunit`, `tanggal`, `jam`, `keterangan`, `action`, `location`) VALUES
(1, '1', 'prasetyo.harry99@gmail.com', 'Harry Prasetyo', 'Developer', 'Department IT Development', '1', '03/11/2021', '02:07:06', 'Ok', 'In', 'France Bread Dan Cakes, Medan 20151, Indonesia');

-- --------------------------------------------------------

--
-- Table structure for table `bukutamu`
--

CREATE TABLE `bukutamu` (
  `id_bukutamu` int(11) NOT NULL,
  `nama` varchar(200) NOT NULL,
  `instansi` varchar(100) NOT NULL,
  `alamat` varchar(200) NOT NULL DEFAULT '0',
  `telp` varchar(100) NOT NULL DEFAULT '0',
  `email` varchar(100) NOT NULL,
  `keperluan` varchar(200) NOT NULL DEFAULT '',
  `suhu` varchar(200) NOT NULL DEFAULT '0',
  `foto` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `pegawai`
--

CREATE TABLE `pegawai` (
  `id` int(11) NOT NULL,
  `rollno` varchar(50) DEFAULT NULL,
  `nidn` varchar(100) DEFAULT NULL,
  `nip` varchar(150) DEFAULT NULL,
  `nama` varchar(255) DEFAULT NULL,
  `jabatan` varchar(255) DEFAULT NULL,
  `unit` varchar(255) DEFAULT NULL,
  `gol` varchar(50) DEFAULT NULL,
  `tmt_gol` varchar(50) DEFAULT NULL,
  `jenis` varchar(255) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `jabatan_fungsional` varchar(255) DEFAULT NULL,
  `tmt_jabatan` varchar(50) DEFAULT NULL,
  `fakultas` varchar(255) DEFAULT NULL,
  `jurusan` varchar(255) DEFAULT NULL,
  `prodi` varchar(255) DEFAULT NULL,
  `pensiun` varchar(50) DEFAULT NULL,
  `pendidikan` varchar(255) DEFAULT NULL,
  `tempat_lahir` varchar(255) DEFAULT NULL,
  `tgl_lahir` varchar(50) DEFAULT NULL,
  `jk` varchar(50) DEFAULT NULL,
  `agama` varchar(150) DEFAULT NULL,
  `npwp` varchar(150) DEFAULT NULL,
  `tmt_ut` varchar(50) DEFAULT NULL,
  `idunit` varchar(255) DEFAULT NULL,
  `trained` varchar(10) DEFAULT 'N',
  `address` varchar(255) DEFAULT NULL,
  `negara` varchar(150) DEFAULT NULL,
  `kota` varchar(200) DEFAULT NULL,
  `kodepos` varchar(100) DEFAULT NULL,
  `tentang` varchar(255) DEFAULT NULL,
  `level` int(11) DEFAULT NULL,
  `slogan` text DEFAULT NULL,
  `profile` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pegawai`
--

INSERT INTO `pegawai` (`id`, `rollno`, `nidn`, `nip`, `nama`, `jabatan`, `unit`, `gol`, `tmt_gol`, `jenis`, `status`, `email`, `jabatan_fungsional`, `tmt_jabatan`, `fakultas`, `jurusan`, `prodi`, `pensiun`, `pendidikan`, `tempat_lahir`, `tgl_lahir`, `jk`, `agama`, `npwp`, `tmt_ut`, `idunit`, `trained`, `address`, `negara`, `kota`, `kodepos`, `tentang`, `level`, `slogan`, `profile`) VALUES
(1, '1', '', '', 'Harry Prasetyo', 'Developer', 'Department IT Development', '', '', '', '', 'prasetyo.harry99@gmail.com', '', '', '', '', '', '', '', '', '', '', '', '', '', '1', 'Y', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tamu`
--

CREATE TABLE `tamu` (
  `id` int(11) NOT NULL,
  `tgl` varchar(50) DEFAULT NULL,
  `nama` varchar(255) DEFAULT NULL,
  `institusi` varchar(255) DEFAULT NULL,
  `kepada` varchar(255) DEFAULT NULL,
  `keperluan` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `unit`
--

CREATE TABLE `unit` (
  `id` int(11) NOT NULL,
  `unit` varchar(255) DEFAULT NULL,
  `idunit` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `unit`
--

INSERT INTO `unit` (`id`, `unit`, `idunit`) VALUES
(1, 'Department IT Development', '1'),
(2, 'Department IT Operation', '2');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `email` varchar(200) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `nama` varchar(255) DEFAULT NULL,
  `rollno` varchar(50) DEFAULT NULL,
  `unit` varchar(255) DEFAULT NULL,
  `idunit` varchar(50) DEFAULT NULL,
  `token` varchar(255) DEFAULT NULL,
  `isactive` varchar(20) DEFAULT NULL,
  `passtoken` varchar(255) DEFAULT NULL,
  `lupapass` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `email`, `password`, `nama`, `rollno`, `unit`, `idunit`, `token`, `isactive`, `passtoken`, `lupapass`) VALUES
(1, 'prasetyo.harry99@gmail.com', '5f4dcc3b5aa765d61d8327deb882cf99', 'Harry Prasetyo', '1', 'Department IT Development', '1', '', '2', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `absensi`
--
ALTER TABLE `absensi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bukutamu`
--
ALTER TABLE `bukutamu`
  ADD PRIMARY KEY (`id_bukutamu`);

--
-- Indexes for table `pegawai`
--
ALTER TABLE `pegawai`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tamu`
--
ALTER TABLE `tamu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `unit`
--
ALTER TABLE `unit`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `absensi`
--
ALTER TABLE `absensi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `bukutamu`
--
ALTER TABLE `bukutamu`
  MODIFY `id_bukutamu` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pegawai`
--
ALTER TABLE `pegawai`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tamu`
--
ALTER TABLE `tamu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `unit`
--
ALTER TABLE `unit`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
