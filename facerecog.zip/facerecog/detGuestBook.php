<?php
include "db.php";
$data=array();
$id=$_POST['id'];

$sql="SELECT * FROM bukutamu WHERE `id_bukutamu`='$id' ORDER BY created_at DESC";

$q=mysqli_query($con,$sql);
while ($row=mysqli_fetch_object($q)){
 $data[]=$row;
}
echo json_encode($data);
?>