<?php
include "db.php";
$data=array();
if(isset($_POST['findAbsen'])){
$email=$_POST["email"];
$tglAwal=$_POST["tglAwal"];
$strTglAwal = date("d/m/Y",strtotime($tglAwal));
$tglAkhir=$_POST["tglAkhir"];
$strTglAkhir = date("d/m/Y",strtotime($tglAkhir));
$sql="SELECT * FROM `absensi` WHERE `email`='$email' AND STR_TO_DATE(`tanggal`,'%d/%m/%Y') >= STR_TO_DATE('$strTglAwal','%d/%m/%Y') AND STR_TO_DATE(`tanggal`,'%d/%m/%Y') <= STR_TO_DATE('$strTglAkhir','%d/%m/%Y') ORDER BY id DESC";

	$q=mysqli_query($con,$sql);
	while ($row=mysqli_fetch_object($q)){
	$data[]=$row;
	}
}
echo json_encode($data);
?>