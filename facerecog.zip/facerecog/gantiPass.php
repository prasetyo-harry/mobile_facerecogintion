<?php
 include "db.php";
 if(isset($_POST['gantiPass']))
 { 
 $email=$_POST['email'];
 $oldpassx=$_POST['oldpass'];
 $oldpass=md5($oldpassx);
 $newpassx=$_POST['newpass'];
 $newpass=md5($newpassx);
 $vernewpass=$_POST['vernewpass'];
 
 
 $z=mysqli_query($con,"SELECT password FROM `user` WHERE `email`='$email'");
	while($ls = mysqli_fetch_array($z,MYSQLI_ASSOC)) {
		$passdb = $ls["password"];
		if($oldpass !=$passdb){
			echo"1";
		}else{
			$q=mysqli_query($con,"UPDATE `user` SET `password`='$newpass' WHERE `email`='$email'");
			if($q)
				echo "success";
			else
				echo "error";
		}
	}
 }
 ?>