<?php
include "db.php";
$data=array();
if(isset($_POST["unit"])){ 
	$q=mysqli_query($con,"SELECT * FROM `unit`");
	while ($row=mysqli_fetch_object($q)){
		$data[]=$row;
	}
	echo json_encode($data);
 }
?>