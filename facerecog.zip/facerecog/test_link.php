<?php
date_default_timezone_set('Asia/Jakarta');
$kota = $_GET['kota'];
$kelurahan = $_GET['kelurahan'];

echo "$kota<br>";
echo "$kelurahan<br>";

$date = date('dmYHis');
echo "$date<br>";

					$first  = new DateTime( '11:35:20' );
					$second = new DateTime( '12:00:45' );

					$diff = $first->diff( $second );

					echo $diff->format( '%H:%I:%S' ); // -> 00:25:25
?>