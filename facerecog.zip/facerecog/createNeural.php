<?php 
header('Access-Control-Allow-Origin: *');
	$rollno = $_POST['rollno'];
	$neuralFile = fopen('data/'.$rollno.'_neural.json', 'w');
	$txt = '[]';
	fwrite($neuralFile, $txt);
	fclose($neuralFile);

?>