<?php
include "db.php";
$data=array();
$email=$_POST["email"];

$q=mysqli_query($con,"SELECT * FROM `pegawai` WHERE `email`='$email'");
	while ($row=mysqli_fetch_object($q)){
		$data[]=$row;
	}
echo json_encode($data);
?>