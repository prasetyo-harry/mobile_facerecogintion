<?php
 include "db.php";
 if(isset($_POST['resetPass']))
 { 
 $email=$_POST['email'];
 $passtoken=$_POST['passtoken'];
 $newpassx=$_POST['newpass'];
 $newpass=md5($newpassx);
 $vernewpass=$_POST['vernewpass'];
 
	$sql = mysqli_query($con,"SELECT id FROM user WHERE email='$email' AND passtoken='$passtoken' AND lupapass='1' AND isactive='2'");
	if ($sql->num_rows > 0) {
		mysqli_query($con,"UPDATE user SET lupapass='2', passtoken='', password='$newpass' WHERE email='$email' ");
		
		echo "success";
	} else {
		echo "error";
	}
 }
 ?>