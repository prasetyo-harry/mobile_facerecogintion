<?php
header('Access-Control-Allow-Origin: *');
$connect = new PDO("mysql:host=localhost;dbname=dbfacerecog", "root", "");
if(isset($_POST["type"]))
{
 if($_POST["type"] == "unit_data")
 {
  $query = "SELECT * FROM unit ORDER BY id ASC";
  $statement = $connect->prepare($query);
  $statement->execute();
  $data = $statement->fetchAll();
  foreach($data as $row)
  {
   $output[] = array(
    'id'  => $row["idunit"],
    'name'  => $row["unit"]
   );
  }
  echo json_encode($output);
 }
}

?>