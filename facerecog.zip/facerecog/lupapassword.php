<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
 
 if(isset($_POST['lupa']))
 {
	$email = $_POST['email'];
	// generate token
	$passtoken = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890!*()$";
	$passtoken = str_shuffle($passtoken);
	$passtoken = substr($passtoken, 0, 10);
	$con = mysqli_connect("localhost","root","","dbfacerecog") or die ("could not connect database");

	$sql = mysqli_query($con,"SELECT id FROM user WHERE email='$email' AND isactive='2'");
	if ($sql->num_rows > 0) {
		mysqli_query($con,"UPDATE user SET lupapass='1', passtoken='$passtoken' WHERE email='$email'");
		
		$mail = new PHPMailer;
		$mail->isSMTP(); 
		$mail->SMTPDebug = 0; 
		$mail->Host = "smtp.yourhost.com"; 
		$mail->Port = "yourport";
		$mail->SMTPSecure = 'tls'; // ssl is depracated
		$mail->SMTPAuth = true;
		$mail->Username = "username@example.com";
		$mail->Password = "your password";
		$mail->setFrom("username@example.com", "F.R.A.S");
		$mail->addAddress($email);
		$mail->Subject = 'Password Reset';
		$mail->msgHTML('<p>Klik <a href="https://localhost/facerecog/resetpass.php?email='.$email.'&passtoken='.$passtoken.'">Reset Password</a> untuk mengganti password akun anda.</p>');
		$mail->AltBody = 'HTML not supported';
		//$mail->addAttachment('docs/brochure.pdf'); //Attachment, can be skipped
		$mail->send();
		
		echo 'success';
	} else {
		echo 'error';
	}
 }
?>