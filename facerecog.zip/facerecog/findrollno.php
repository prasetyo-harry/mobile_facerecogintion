<?php
header('Access-Control-Allow-Origin: *');
include "db.php";
$rollno=$_POST['rollno'];
$data=array();
$q=mysqli_query($con,"SELECT * FROM `pegawai` WHERE rollno='$rollno'");
while ($row=mysqli_fetch_object($q)){
 $data[]=$row;
}
echo json_encode($data);
?>