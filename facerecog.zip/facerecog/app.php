<?php
header('Access-Control-Allow-Origin: *');
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

$conn = mysqli_connect("localhost","root","","dbfacerecog") or die("could not connect server");


/********************************* LOGIN MOBILE **********************************************************************************************/
if(isset($_POST['login']))
{
	$email=mysqli_real_escape_string($conn, htmlspecialchars(trim($_POST['email'])));
	$passwordx=mysqli_real_escape_string($conn, htmlspecialchars(trim($_POST['password'])));
	$password=md5($passwordx);
	$login=mysqli_num_rows(mysqli_query($conn, "SELECT * FROM `user` WHERE `email`='$email' AND `password`='$password' AND `isactive`='2'"));
	if($login!=0)
	{
		echo "success";
	}
	else
	{
		echo "failed";
	}
}
/**************************************************************** END LOGIN MOBILE ******************************************************************/


/********************************************************************************** UPDATE PROFILE ***************************************************************/
if(isset($_POST['updateProfile']))
{	
	$rollno=mysqli_real_escape_string($conn, htmlspecialchars(trim($_POST['rollno'])));
	$nidn=mysqli_real_escape_string($conn, htmlspecialchars(trim($_POST['nidn'])));
	$nip=mysqli_real_escape_string($conn, htmlspecialchars(trim($_POST['nip'])));
	$nama=mysqli_real_escape_string($conn, htmlspecialchars(trim($_POST['nama'])));
	$jabatan=mysqli_real_escape_string($conn, htmlspecialchars(trim($_POST['jabatan'])));
	$unit=mysqli_real_escape_string($conn, htmlspecialchars(trim($_POST['unit'])));
	$gol=mysqli_real_escape_string($conn, htmlspecialchars(trim($_POST['gol'])));
	$tmt_gol=mysqli_real_escape_string($conn, htmlspecialchars(trim($_POST['tmt_gol'])));
	$jenis=mysqli_real_escape_string($conn, htmlspecialchars(trim($_POST['jenis'])));
	$status=mysqli_real_escape_string($conn, htmlspecialchars(trim($_POST['status'])));
	$email=mysqli_real_escape_string($conn, htmlspecialchars(trim($_POST['email'])));
	$jabatan_fungsional=mysqli_real_escape_string($conn, htmlspecialchars(trim($_POST['jabatan_fungsional'])));
	$tmt_jabatan=mysqli_real_escape_string($conn, htmlspecialchars(trim($_POST['tmt_jabatan'])));
	$tmt_ut=mysqli_real_escape_string($conn, htmlspecialchars(trim($_POST['tmt_ut'])));
	$fakultas=mysqli_real_escape_string($conn, htmlspecialchars(trim($_POST['fakultas'])));
	$jurusan=mysqli_real_escape_string($conn, htmlspecialchars(trim($_POST['jurusan'])));
	$prodi=mysqli_real_escape_string($conn, htmlspecialchars(trim($_POST['prodi'])));
	$pensiun=mysqli_real_escape_string($conn, htmlspecialchars(trim($_POST['pensiun'])));
	$pendidikan=mysqli_real_escape_string($conn, htmlspecialchars(trim($_POST['pendidikan'])));
	$tempat_lahir=mysqli_real_escape_string($conn, htmlspecialchars(trim($_POST['tempat_lahir'])));
	$tgl_lahir=mysqli_real_escape_string($conn, htmlspecialchars(trim($_POST['tgl_lahir'])));
	$jk=mysqli_real_escape_string($conn, htmlspecialchars(trim($_POST['jk'])));
	$agama=mysqli_real_escape_string($conn, htmlspecialchars(trim($_POST['agama'])));
	$npwp=mysqli_real_escape_string($conn, htmlspecialchars(trim($_POST['npwp'])));
	$address=mysqli_real_escape_string($conn, htmlspecialchars(trim($_POST['address'])));
	$negara=mysqli_real_escape_string($conn, htmlspecialchars(trim($_POST['negara'])));
	$kota=mysqli_real_escape_string($conn, htmlspecialchars(trim($_POST['kota'])));
	$kodepos=mysqli_real_escape_string($conn, htmlspecialchars(trim($_POST['kodepos'])));
	$tentang=mysqli_real_escape_string($conn, htmlspecialchars(trim($_POST['tentang'])));

	$updateProfile=mysqli_query($conn, "UPDATE pegawai SET nidn='$nidn', nip='$nip', nama='$nama', jabatan='$jabatan', unit='$unit', gol='$gol',tmt_gol='$tmt_gol', jenis='$jenis', status='$status', jabatan_fungsional='$jabatan_fungsional', tmt_jabatan='$tmt_jabatan', fakultas='$fakultas', jurusan='$jurusan', prodi='$prodi', pensiun='$pensiun', pendidikan='$pendidikan', tempat_lahir='$tempat_lahir', tgl_lahir='$tgl_lahir', jk='$jk', agama='$agama', npwp='$npwp', address='$address', negara='$negara', kota='$kota', kodepos='$kodepos', tentang='$tentang', tmt_ut='$tmt_ut' WHERE rollno='$rollno' AND email='$email' ");
	if($updateProfile)
	{
		echo "success";
	}
	else
	{
		echo "failed";
	}
}
/**************************************************************** END UPDATE PROFILE ******************************************************************/

//Login WEB
if(isset($_POST['webLogin']))
{
	session_start();
	$email=mysqli_real_escape_string($conn, htmlspecialchars(trim($_POST['email'])));
	$passwordx=mysqli_real_escape_string($conn, htmlspecialchars(trim($_POST['password'])));
	$password=md5($passwordx);
	$webLogin=mysqli_query($conn, "SELECT * FROM `user` WHERE `email`='$email' AND `password`='$password' AND `isactive`='2'");
	$num_row=mysqli_num_rows($webLogin);
	$row = mysqli_fetch_assoc($webLogin);
	
	if(is_array($row) && !empty($row)) {
		$validuser = $row['email'];
		$_SESSION['valid'] = $validuser;
		$_SESSION['id'] = $row['id'];
		$_SESSION['nama'] = $row['nama'];
		$_SESSION['rollno'] = $row['rollno'];
		$_SESSION['unit'] = $row['unit'];
		$_SESSION['idunit'] = $row['nama'];
	}
	
	if($num_row !=0)
	{
		echo "success";
	}
	else
	{
		echo "failed";
	}
}

//Create New Account From Existing Employee
if(isset($_POST['btnDaftar']))
{
	$email=mysqli_real_escape_string($conn,htmlspecialchars(trim($_POST['email'])));
	$unit=mysqli_real_escape_string($conn,htmlspecialchars(trim($_POST['unit'])));
	$nama=mysqli_real_escape_string($conn,htmlspecialchars(trim($_POST['nama'])));
	$rollno=mysqli_real_escape_string($conn,htmlspecialchars(trim($_POST['rollno'])));
	$passwordx=mysqli_real_escape_string($conn,htmlspecialchars(trim($_POST['password'])));
	$password=md5($passwordx);
	
	$signupx=mysqli_num_rows(mysqli_query($conn,"SELECT * FROM `user` WHERE `email`='$email'"));
	if(!$signupx ==0)
	{
		echo "exist";
	}
	else
	{
		$idxxx=mysqli_query($conn,"SELECT rollno FROM pegawai WHERE email ='$email'");
		$idxx = mysqli_fetch_row($idxxx); 
		$idx=$idxx[0];
		$id=intval($idx);
		$rollno=$id;
		
		$idunitxxx=mysqli_query($conn,"SELECT idunit FROM unit WHERE `unit`='$unit'");
		$idunitxx=mysqli_fetch_row($idunitxxx);
		$idunitx=$idunitxx[0];
		$idunit=$idunitx;
		
		// generate token
	    $token = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890!*()$";
	    $token = str_shuffle($token);
		$token = substr($token, 0, 10);
		
		$q=mysqli_query($conn,"INSERT INTO `user` (`id`,`email`,`password`,`nama`,`rollno`,`unit`,`idunit`,`token`,`isactive`) VALUES (default,'$email','$password','$nama','$rollno','$unit','$idunit','$token','1')");
		
		$mail = new PHPMailer;
		$mail->isSMTP(); 
		$mail->SMTPDebug = 0; 
		$mail->Host = "yourhost"; 
		$mail->Port = "port"; // typically 587 
		$mail->SMTPSecure = 'tls'; // ssl is depracated
		$mail->SMTPAuth = true;
		$mail->Username = "username@example.com";
		$mail->Password = "yourpassword";
		$mail->setFrom("username@example.com", "F.R.A.S");
		$mail->addAddress($email, $nama);
		$mail->Subject = 'Account Activation';
		$mail->msgHTML('<p>Hello '.$nama.',<br>Click <a href="https://localhost/facerecog/confirm.php?email='.$email.'&token='.$token.'">Activation</a> to activate your account.</p>');
		$mail->AltBody = 'HTML not supported';
		//$mail->addAttachment('docs/brochure.pdf'); //Attachment, can be skipped
		$mail->send();
		
		if($q)
		{
			echo "success";
		}
		else
		{
			echo "failed";
		}
	}
	echo mysqli_error($conn);
}

//Create New Account From Non Exist Employee
if(isset($_POST['signup']))
{
	//echo "MASUK 1<br>";
	$email=mysqli_real_escape_string($conn,htmlspecialchars(trim($_POST['email'])));
	$unit=mysqli_real_escape_string($conn,htmlspecialchars(trim($_POST['unit'])));
	$nama=mysqli_real_escape_string($conn,htmlspecialchars(trim($_POST['nama'])));
	//$rollno=mysqli_real_escape_string($conn,htmlspecialchars(trim($_POST['rollno'])));
	$passwordx=mysqli_real_escape_string($conn,htmlspecialchars(trim($_POST['password'])));
	$password=md5($passwordx);
	$jabatan=mysqli_real_escape_string($conn,htmlspecialchars(trim($_POST['jabatan'])));
	
	$sign=mysqli_num_rows(mysqli_query($conn,"SELECT * FROM `pegawai` WHERE `email`='$email'"));
	$signx=mysqli_num_rows(mysqli_query($conn,"SELECT * FROM `user` WHERE `email`='$email'"));
	//echo "SIGNUPX================== $signx<br>";
	//echo "SIGNUP================== $sign<br>";
	if($sign !=0 || $signx !=0)
	{
		echo "exist";
	}
	else
	{
		//echo "MASUK 2<br>";
		$idxxx=mysqli_query($conn,"SELECT MAX(id) FROM pegawai");
		$idxx = mysqli_fetch_row($idxxx); 
		$idx=$idxx[0];
		$id=intval($idx)+1;
		$rollno=$id;
		
		$idunitxxx=mysqli_query($conn,"SELECT idunit FROM unit WHERE `unit`='$unit'");
		$idunitxx=mysqli_fetch_row($idunitxxx);
		$idunitx=$idunitxx[0];
		$idunit=$idunitx;
		//echo "IDUNIT =========$idunit<br>";
		$z=mysqli_query($conn,"INSERT INTO `pegawai` (`id`,`rollno`,`nidn`,`nip`,`nama`,`jabatan`,`unit`,`gol`,`tmt_gol`,`jenis`,`status`,`email`,`jabatan_fungsional`,`tmt_jabatan`,`fakultas`,`jurusan`,`prodi`,`pensiun`,`pendidikan`,`tempat_lahir`,`tgl_lahir`,`jk`,`agama`,`npwp`,`tmt_ut`,`idunit`,`trained`) VALUES (default,'$rollno','','','$nama','$jabatan','$unit','','','','','$email','','','','','','','','','','','','','','$idunit','N')");
		
		// generate token
	    $token = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890!*()$";
	    $token = str_shuffle($token);
		$token = substr($token, 0, 10);
		
		$q=mysqli_query($conn,"INSERT INTO `user` (`id`,`email`,`password`,`nama`,`rollno`,`unit`,`idunit`,`token`,`isactive`,`passtoken`,`lupapass`) VALUES (default,'$email','$password','$nama','$rollno','$unit','$idunit','$token','1','','')");
		
		$mail = new PHPMailer;
		$mail->isSMTP(); 
		$mail->SMTPDebug = 0; 
		$mail->Host = "yourhost"; 
		$mail->Port = "port"; // typically 587 
		$mail->SMTPSecure = 'tls'; // ssl is depracated
		$mail->SMTPAuth = true;
		$mail->Username = "username@example.com";
		$mail->Password = "yourpass";
		$mail->setFrom("username@example.com", "F.R.A.S");
		$mail->addAddress($email, $nama);
		$mail->Subject = 'Account Activation';
		$mail->msgHTML('<p>Hello '.$nama.',<br>Click <a href="https://localhost/facerecog/confirm.php?email='.$email.'&token='.$token.'">Activation</a> to activate your account.</p>');
		$mail->AltBody = 'HTML not supported';
		//$mail->addAttachment('docs/brochure.pdf'); //Attachment, can be skipped
		$mail->send();
		
		if($z and $q)
		{
			echo "success";
		}
		else
		{
			echo "failed";
		}
	}
	echo mysqli_error($conn);
}

?>