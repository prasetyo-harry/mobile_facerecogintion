<?php
header('Access-Control-Allow-Origin: *');
include 'db.php';
date_default_timezone_set('Asia/Jakarta');

 if(isset($_POST['absen']))
 {
	$email=$_POST['email'];
	$loc=$_POST['loc'];
	$a=mysqli_query($con,"SELECT * FROM `pegawai` WHERE `email`='$email'");
	
	while($rs = mysqli_fetch_array($a,MYSQLI_ASSOC)) {
		$id="";
		$rollno = $rs["rollno"];
		$mail = $rs["email"];
		$nama = $rs["nama"];
		$jabatan = $rs["jabatan"];
		$unit = $rs["unit"];
		$idunit = $rs["idunit"];
		$waktu = date('d/m/Y-H:i:s');
		$tglSekarang = date('d/m/Y');
		$jamSekarang = date('H:i:s');  
		$keterangan="";
		$action="";
		}
		$b = mysqli_query($con,"SELECT * FROM `absensi` WHERE `email`='$email' AND `tanggal`='$tglSekarang'");
		$num_rows = mysqli_num_rows($b);
		if($num_rows == 0){
			$action = "In";
			if(strtotime($jamSekarang) > strtotime("08:30:00")){
				$keterangan = "Late";
				}else{
					$keterangan = "Ok";
				}
		$q = mysqli_query($con,"INSERT INTO `absensi`(`id`,`rollno`,`email`,`nama`,`jabatan`,`unit`,`idunit`,`tanggal`,`jam`,`keterangan`,`action`,`location`) VALUES (default,'$rollno','$mail','$nama','$jabatan','$unit','$idunit','$tglSekarang','$jamSekarang','$keterangan','$action','$loc')");
			if($q){
			   echo "success";
			}else{
			    echo "error";	
			}
		}else if($num_rows == 1){
			$action = "Out";
			$c = mysqli_query($con,"SELECT jam FROM `absensi` WHERE `email`='$email' AND `tanggal`='$tglSekarang' AND `action`='In'"); 
			$rows = mysqli_num_rows($c);
			while($rs = mysqli_fetch_array($c,MYSQLI_ASSOC)){
				$jamDatang = $rs["jam"];
				$datang = new DateTime($jamDatang);
				$pulang = new DateTime($jamSekarang);
				$ket = $datang->diff($pulang);
				$keterangan = $ket->format('%H:%I:%S');
			}
		$z = mysqli_query($con,"INSERT INTO `absensi`(`id`,`rollno`,`email`,`nama`,`jabatan`,`unit`,`idunit`,`tanggal`,`jam`,`keterangan`,`action`,`location`) VALUES (default,'$rollno','$mail','$nama','$jabatan','$unit','$idunit','$tglSekarang','$jamSekarang','$keterangan','$action','$loc')");
			if($z){
			   echo "success";
			}else{
			    echo "error";	
			}
		} else {
			$d = mysqli_query($con,"SELECT jam FROM `absensi` WHERE `email`='$email' AND `tanggal`='$tglSekarang' AND `action`='In'");
			while($rs = mysqli_fetch_array($d,MYSQLI_ASSOC)){
				$jamDatang = $rs["jam"];
				$datang = new DateTime($jamDatang);
				$pulang = new DateTime($jamSekarang);
				$ket = $datang->diff($pulang);
				$keterangan = $ket->format('%H:%I:%S');
			}
		$x = mysqli_query($con,"UPDATE `absensi` SET `jam` = '$jamSekarang', `keterangan` = '$keterangan', `location` = '$loc' WHERE `email`='$email' AND `tanggal`='$tglSekarang' AND `action`='Out'");
			if($x){
			   echo "success";
			}else{
			    echo "error";	
			}
		}
	}
 ?>