<?php
 include "db.php";
  if(isset($_POST['trained']))
 {
 $rollno=trim($_POST['rollno']);
 $sql="UPDATE `pegawai` SET `trained`='Y' WHERE `rollno`='$rollno' ";

 $q=mysqli_query($con,$sql);

 if($q)
  echo "success";
 else
  echo "error";
 }
 ?>