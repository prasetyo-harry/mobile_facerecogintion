<!DOCTYPE html>
<html>
  <head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>Face Recognition Attendance System</title>
  <link href="../css/loader.css" rel="stylesheet">
  <link href="../css/bootstrap.min.css" rel="stylesheet">
  <style type="text/css">    
@media (min-width: 768px) {
    .omb_row-sm-offset-3 div:first-child[class*="col-"] {
        margin-left: 25%;
    }
}

.omb_login .omb_authTitle {
    text-align: center;
	line-height: 300%;
}
	
.omb_login .omb_socialButtons a {
	color: white; // In yourUse @body-bg 
	opacity:0.9;
}
.omb_login .omb_socialButtons a:hover {
    color: white;
	opacity:1;    	
}
.omb_login .omb_socialButtons .omb_btn-facebook {background: #3b5998;}
.omb_login .omb_socialButtons .omb_btn-twitter {background: #00aced;}
.omb_login .omb_socialButtons .omb_btn-google {background: #c32f10;}


.omb_login .omb_loginOr {
	position: relative;
	font-size: 1.5em;
	color: #aaa;
	margin-top: 1em;
	margin-bottom: 1em;
	padding-top: 0.5em;
	padding-bottom: 0.5em;
}
.omb_login .omb_loginOr .omb_hrOr {
	background-color: #cdcdcd;
	height: 1px;
	margin-top: 0px !important;
	margin-bottom: 0px !important;
}
.omb_login .omb_loginOr .omb_spanOr {
	display: block;
	position: absolute;
	left: 50%;
	top: -0.6em;
	margin-left: -1.5em;
	background-color: white;
	width: 3em;
	text-align: center;
}			

.omb_login .omb_loginForm .input-group.i {
	width: 2em;
}
.omb_login .omb_loginForm  .help-block {
    color: red;
}

	
@media (min-width: 768px) {
    .omb_login .omb_forgotPwd {
        text-align: center;
		margin-top:10px;
 	}		
}

/* Add a black background color to the top navigation */
.topnav {
  background-color: #333;
  overflow: hidden;
}

/* Style the links inside the navigation bar */
.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 14px;
}

/* Change the color of links on hover */
.topnav a:hover {
  background-color: #ddd;
  color: black;
}

/* Add a color to the active/current link */
.topnav a.active {
  background-color: #4CAF50;
  color: white;
}
    </style>
	<script type="text/javascript" src="../js/jquery.js"></script>
    <script src="../js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="../css/font-awesome.min.css">
	<script type="text/javascript">
    $(document).ready(function () {
      $('#backBtn').click(function () {
        parent.history.back();
        return false;
		});
	});
	</script>
	<link rel="stylesheet" href="../css/responsive.bootstrap.min.css">
    <script type="text/javascript">
	function getUrlVars() {
		var vars = [], hash;
		var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
		for(var i = 0; i < hashes.length; i++){
			hash = hashes[i].split('=');
			vars.push(hash[0]);
			vars[hash[0]] = hash[1];
			}
		return vars;
		}
	var email = getUrlVars()["email"];
	var passtoken = getUrlVars()["passtoken"];


    $(document).ready(function() {
        $("#resetPass").click(function() {
			var newpass = document.getElementById("newpass").value;
			var vernewpass = document.getElementById("vernewpass").value;
		
			if(newpass ==''){
				alert('New Password Required!');
				return false;
			}
			if(vernewpass ==''){
				alert('New Verify Password Required!');
				return false;
			}
			if(vernewpass!==newpass){
				alert('Verify Password and New Password Not Same');
				return false;
			}

			var dataString = "email="+email+"&passtoken="+passtoken+"&newpass="+newpass+"&vernewpass="+vernewpass+"&resetPass=";
			if ($.trim(email).length > 0 && $.trim(passtoken).length > 0 && $.trim(newpass).length > 0 && $.trim(vernewpass).length > 0) {
	
                $.ajax({
                    type: "POST",
                    url: "https://localhost/facerecog/passReset.php",
                    data: dataString,
                    crossDomain: true,
                    cache: false,
                    beforeSend: function() {
                        $("#resetPass").val('Connecting...');
                    },
                    success: function(data) {
					console.log(data);
                        if (data=='success') {
							alert('Succeed!');
							window.location.href = "https://localhost/facerecog";
                        } else {
                            alert("Failed!");
							window.location.href = "https://localhost/facerecog";
                        }
                    }
                });
            }
			return false;
        });
		
    });
    </script>
<script>
  $(window).on('load', function(){$(".se-pre-con").fadeOut("slow"); });
  </script>
</head>

<body>
<div class="se-pre-con"></div>
<nav class="navbar navbar-expand-md navbar-light" style="background-color:none;">
</nav>
<div class="container">
    <div class="omb_login">
    	<h4 class="omb_authTitle">Reset Password</h4>
		<div class="row omb_row-sm-offset-3">
			<div class="col-xs-12 col-sm-6">	
			    <form class="omb_loginForm" autocomplete="off">

				<div class="input-group">
					<span class="input-group-addon"><i class="fa fa-archive"></i></span>
					<input  type="password" class="form-control" name="newpass" id="newpass" placeholder="New Password" required>
				</div>
				<span class="help-block"></span>				

				<div class="input-group">
					<span class="input-group-addon"><i class="fa fa-archive"></i></span>
					<input  type="password" class="form-control" name="vernewpass" id="vernewpass" placeholder="Repeat New Password" required>
				</div>
				<span class="help-block"></span>
					
				<button class="btn btn-lg btn-primary btn-block" type="submit" name="resetPass" id="resetPass">UPDATE</button>
				<div>&nbsp;</div>
				<div>&nbsp;</div>
				<div>&nbsp;</div>
				<div>&nbsp;</div>
				<div>&nbsp;</div>
				<div>&nbsp;</div>
				<div>&nbsp;</div>
				<center><a href="https://github.com/prasetyo-harry/">&copy; Hari Prasetyo</a></center>
				</form>
			</div>
    	</div>	    	
	</div>
</div>
<script type="text/javascript" src="../js/app.js"></script>

</body>
</html>