<?php 
header('Access-Control-Allow-Origin: *');
	$data = $_POST['myData'];

	
	$jsonRoll = json_decode($data, true);
	$rollno = $jsonRoll['_label'];
	
	$json = file_get_contents('data/'.$rollno.'_neural.json');

	if(strlen($json) > 2){
		$string = ',' . $data; 
	}
	else{
		$string = $data;
	}
	$position = strlen($json) - 1; 
	$out = substr_replace( $json, $string, $position, 0 ); 

	file_put_contents('data/'.$rollno.'_neural.json', $out);
?> 
