<?php

include "db.php";
$data=array();

$tglSkrx = date('d/m/Y');
$sql="SELECT * FROM `tamu` ORDER BY id DESC LIMIT 10";
$q=mysqli_query($con,$sql);
while ($row=mysqli_fetch_object($q)){
 $data[]=$row;
}
echo json_encode($data);
?>