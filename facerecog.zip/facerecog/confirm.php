<?php
	$email = $_GET['email'];
	$token = $_GET['token'];

	$con = mysqli_connect("localhost","root","","dbfacerecog") or die ("could not connect database");

	$sql = mysqli_query($con,"SELECT id FROM user WHERE email='$email' AND token='$token' AND isactive='1'");
	if ($sql->num_rows > 0) {
		mysqli_query($con,"UPDATE user SET isactive='2', token='' WHERE email='$email' ");
		
		echo '<script>';
		echo 'alert("Succeed!");';
		//echo 'open(location,_self).close();';
		echo 'window.location.href="https://localhost/facerecog"';
		echo '</script>';
	} else {
		echo '<script>';
		echo 'alert("Failed!");';
		//echo 'open(location,_self).close();';
		echo 'window.location.href="https://localhost/facerecog"';
		echo '</script>';
	}
?>