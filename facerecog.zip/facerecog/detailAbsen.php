<?php
include "db.php";
$data=array();
$id=$_POST["id"];

$q=mysqli_query($con,"SELECT * FROM `absensi` WHERE `id`='$id' ORDER BY id DESC");
while ($row=mysqli_fetch_object($q)){
 $data[]=$row;
}
echo json_encode($data);
?>