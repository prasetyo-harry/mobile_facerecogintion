<?php

include "db.php";
$data=array();
$email=$_POST['email'];
$tglSkrx = date('d/m/Y');
$blnSkr = substr("$tglSkrx",3,2);
$thnSkr = substr("$tglSkrx",6,4);

$sql="SELECT * FROM `absensi` WHERE `email`='$email' ORDER BY id DESC LIMIT 5";
$q=mysqli_query($con,$sql);
while ($row=mysqli_fetch_object($q)){
 $data[]=$row;
}
echo json_encode($data);
?>