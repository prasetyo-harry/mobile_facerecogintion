<?php
include "db.php";
$data=array();
$email=$_POST["email"];
$q=mysqli_query($con,"SELECT * FROM `absensi` WHERE `email`='$email' ORDER BY id DESC LIMIT 30");
while ($row=mysqli_fetch_object($q)){
 $data[]=$row;
}
echo json_encode($data);
?>