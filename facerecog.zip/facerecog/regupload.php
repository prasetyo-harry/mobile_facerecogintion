<?php
header('Access-Control-Allow-Origin: *');
date_default_timezone_set('Asia/Jakarta');

if(isset($_GET['facereg'])) {
	
$date = date('dmYHis');
$rollno = $_GET['rollno'];
$nama = $_GET['nama'];
$jabatan = $_GET['nama'];
$unit = $_GET['nama'];
$email = $_GET['email'];

$folder = mkdir('../upload/'.$rollno, 0777, true);

// Set new file name
$img_name = $rollno."_".$date.".jpg";
// upload file
move_uploaded_file($_FILES["file"]["tmp_name"], '../upload/'.$rollno.'/'.$img_name);

echo $img_name ;
}
?>