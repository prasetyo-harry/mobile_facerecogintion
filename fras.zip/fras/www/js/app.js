$(document).ready(function(){
	var url="https://localhost/facerecog/app.php?callback=?";
    
	//Login Function
    $("#login").click(function(){
    	var email=$("#email").val();
    	var pass=$("#password").val();
		if(email ==''){
			alert('Insert your email!');
			return false;
		}
		if(pass ==''){
			alert('Insert your password!');
			return false;
		}
    	var dataString="email="+email+"&password="+pass+"&login=";
    	if($.trim(email).length>0 & $.trim(pass).length>0)
		{
			$.ajax({
				type: "POST",
				url: url,
				data: dataString,
				crossDomain: true,
				cache: false,
				beforeSend: function(){ $("#login").html('Connecting...');},
				success: function(data){
					if(data=="success")
					{
						localStorage.login="true";
						localStorage.email=email;
						window.location.href = "index.html";
					}
					else if(data="failed")
					{
						alert("Login error");
						$("#login").html('Login');
					}
				}
			});
		}
		return false;
    });
	
	
    //exist-signup function
    $("#btnDaftar").click(function(){
    	var rollno=$("#rollno").val();
		var nama=$("#nama").val();
		var jabatan=$("#jabatan").val();
    	var unit=$("#unit").val();
    	var email=$("#email").val();
		var pass=$("#password").val();
		var verpass=$("#verpassword").val();
		if(pass != verpass){
			alert('Password and Verify Password Not Same');
			return false;
		}
    	var dataString="email="+email+"&password="+pass+"&nama="+nama+"&rollno="+rollno+"&unit="+unit+"&btnDaftar=";

    	if($.trim(email).length>0 & $.trim(pass).length>0 & $.trim(nama).length>0 & $.trim(rollno).length>0 & $.trim(unit).length>0)
		{
			$.ajax({
				type: "POST",
				url: url,
				data: dataString,
				crossDomain: true,
				cache: false,
				beforeSend: function(){ $("#btnDaftar").val('Connecting...');},
				success: function(data){
					if(data=="success")
					{
						alert("Please activate your account by clicking the link we've sent to your email");
						window.location.href="login.html";
					}
					else if(data="exist")
					{
						alert("Account already exist");
					}
					else 
					{
						alert("Registration failed");
					}
				}
			});
		}return false;

    });
	
    //signup function
    $("#signup").click(function(){

		var nama=$("#nama").val();
		//alert(nama);
		var jabatan=$("#jabatan").val();
		//alert(jabatan);
    	var unit=$("#unit").val();
		//alert(unit);
    	var email=$("#email").val();
		//alert(email);
		var pass=$("#password").val();
		//alert(password);
		var verpass=$("#verpassword").val();
		//alert(verpassword);
		if(pass != verpass){
			alert('Password and Verify Password Not Same');
			return false;
		}
    	var dataString="email="+email+"&password="+pass+"&nama="+nama+"&unit="+unit+"&jabatan="+jabatan+"&signup=";
		alert(dataString);
    	if($.trim(email).length>0 & $.trim(pass).length>0 & $.trim(nama).length>0 & $.trim(unit).length>0 & $.trim(jabatan).length>0)
		{
			$.ajax({
				type: "POST",
				url: url,
				data: dataString,
				crossDomain: true,
				cache: false,
				beforeSend: function(){ $("#signup").val('Connecting...');},
				success: function(data){
					if(data=="success")
					{
						alert("Registration succeed, please login and take pics");
						window.location.href="login.html";
					}
					else if(data="exist")
					{
						alert("Account already exist");
					}
					else 
					{
						alert("Registration failed");
					}
				}
			});
		}return false;

    });
	

    //logout function
    $("#logout").click(function(){
    	localStorage.login="false";
    	window.location.href = "login.html";
    });
	
});